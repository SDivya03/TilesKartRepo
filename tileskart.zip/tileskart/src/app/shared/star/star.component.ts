import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { getRandomString } from 'selenium-webdriver/safari';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit,OnChanges {

  @Input() rating;
  ratingWidth:number=65;

  constructor() { }

  ngOnInit() {
  }
  ngOnChanges()
  {
    this.ratingWidth=this.rating*65/5;
  }

}
