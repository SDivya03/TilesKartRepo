import { Component, OnInit } from '@angular/core';
import { ITile } from '../itile';
import { TileService } from '../tile.service';

@Component({
  selector: 'app-tiles',
  templateUrl: './tiles.component.html',
  styleUrls: ['./tiles.component.css']
})
export class TilesComponent implements OnInit {
  // tile :any = {
  //   name: 'kajaria',
  //   model: 'nit-01',
  //   price: 200,
  //   rating: 2,
  //   image: 'tile1.jpg',
  //   status: 1,
  //   Id: 1
  // };
  imagePath:string="/assets/images/";
  filterOptions: Array<string> = ["name", "model", "price"];
  selectedFilter:string = '';
  filterText: string = "";
  tiles:Array<ITile> ;

  filteredTiles:Array<ITile>;
 
  performFilter(filterOption:string,filterText:string,tilesArray:Array<ITile>){
    let filteredTilesArray:Array<ITile>;
    filteredTilesArray =  tilesArray.filter((tile)=>{
        if(filterOption =="name"){
         return  tile.name.toLocaleUpperCase().indexOf(filterText.toLocaleUpperCase())>= 0;
        }
    })
    return filteredTilesArray;
  }
  filter() {
    this.filteredTiles = this.performFilter(this.selectedFilter,this.filterText,this.tiles);
   }
     
  constructor(private tileservice:TileService) {
    this.tiles =this.tileservice.getTilesdate();
    this.filteredTiles=this.tiles;
 
  }
 

  ngOnInit() {
  }

}
