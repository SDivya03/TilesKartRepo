import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TileService } from 'src/app/tile.service';

@Component({
  selector: 'app-tile-detail',
  templateUrl: './tile-detail.component.html',
  styleUrls: ['./tile-detail.component.css']
})
export class TileDetailComponent implements OnInit {
  imagePath:string="/assets/images/";
  constructor(private activateRoute:ActivatedRoute,private tileservice:TileService) { }

  ngOnInit() {
    let id=+this.activateRoute.snapshot.paramMap.get('id');
    // this.tileservice.gettile(id).subscribe
    // {

    // }
  }

}
