import { Injectable } from '@angular/core';
import { ITile } from './itile';

@Injectable({
  providedIn: 'root'
})
export class TileService {

  tiles:Array<ITile> =[
    {
      id:1,
     image:"tile1.jpg",
      name:"kajaria",
      model:"nit-01",
      price :200,
      rating:3,
      status:1
      
    },
    {
      id:2,
      image:"tile2.jpg",
      name:"johnson",
      model:"nit-02",
      price :100,
      rating:2,
      status:0
      
    },
    {
      id:3,
      image:"tile3.jpg",
      name:"hsil",
      model:"nit-03",
      price :300,
      rating:4,
      status:0
    },
    {
      id:4,
      image:"tile4.jpg",
      name:"clayhaus",
      model:"nit-04",
      price :500,          
      rating:1,
      status:1
    },
  ]
  constructor() { }
  getTilesdate()
  {
    return this.tiles;
  }
  gettile(id)
  {
    return this.tiles.indexOf(id);
  }
}
