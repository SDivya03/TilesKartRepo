import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 userName : string='Divya';
 passWord: string;
 showErrorMessage:boolean=false;

 
 constructor(private route:Router) {}

 login(){
  if(this.userName == null || this.userName == ""){
    alert("user name is required");
    this.showErrorMessage=true;
  }
  else
  {
    console.log('You are good to Login');
    this.route.navigate(['/tiles']);
  }
  }


  ngOnInit() {
  }

}
