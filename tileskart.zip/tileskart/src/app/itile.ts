export interface ITile {
  id:number;
  name: string;
  model:string;
  price: number;
  rating: number;
   image: string;
  status: number;
}
